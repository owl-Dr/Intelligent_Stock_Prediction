from dotenv import load_dotenv
import requests
import os
from datetime import datetime

load_dotenv()  # This loads the variables from .env

NEWS_API_KEY = os.getenv('NEWS_API_KEY')
search_url = "https://newsapi.org/v2/everything"

def newsapi_search_news(company_name: str):
    headers = {"Authorization": f"Bearer {NEWS_API_KEY}"}
    params  = {
        "q": f"{company_name} stock price and finance news",
        "language": "en",  # Search in English
        "sortBy": "publishedAt",
        "pageSize": 100,
    }
    response = requests.get(search_url, headers=headers, params=params)
    response.raise_for_status()
    search_results = response.json()

    current_month = datetime.now().month
    current_year = datetime.now().year

    filtered_articles = []
    for article in search_results["articles"]:
        # Adjust the date format
        date_str = article["publishedAt"]
        # Convert date to ISO format and adjust
        published_date = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        if published_date.month == current_month and published_date.year == current_year:
            filtered_articles.append(article)

    return filtered_articles
